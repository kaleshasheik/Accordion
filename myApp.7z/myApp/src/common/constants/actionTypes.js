export const actionTypes = {
  
    LOAD_ACCORDION_DATA: 'LOAD_ACCORDION_DATA'
   
  }