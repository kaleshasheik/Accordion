export const appConstants = {
      APP : 'root'
  }

